
        <script src="<?php echo e(asset('/js/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/js.cookie.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.blockui.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/bootstrap-switch.min.js')); ?>" type="text/javascript"></script>

        <script src="<?php echo e(asset('/js/moment.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/morris.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/daterangepicker.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/raphael-min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.waypoints.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.counterup.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/fullcalendar.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.flot.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.flot.resize.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.flot.categories.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.easypiechart.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.sparkline.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/jquery.vmap.js')); ?>" type="text/javascript"></script>

        <!-- END CORE PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        

        <script src="<?php echo e(asset('/js/app.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/dashboard.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo e(asset('/js/layout.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/demo.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/quick-sidebar.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('/js/quick-nav.min.js')); ?>" type="text/javascript"></script>