    <div class="col-md-3">

        <div class="inbox-sidebar">
                                        
            <div class="row">
                
                <div class="col-md-3">

                    <div class="form-group">
                        <label>By Person</label>
                    </div><!-- end form-group -->
                                        		
                </div><!-- end col-md-3 -->

                <div class="col-md-9">

                    <form method="get">

                    <div class="form-group">
                        <label>Name (in Chinese)</label>
                        <input type="text" class="form-control" placeholder="" id="q" name="chinese_name"> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>Devotee ID</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>Member ID</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>Bridging ID</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>Family Code</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>NRIC No</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    </form>

                </div><!-- end col-md-9 -->

            </div><!-- end row -->

            <div class="row">
                
                <div class="col-md-3">

                    <div class="form-group">
                        <label>By Address</label>
                    </div><!-- end form-group -->
                                        		
                </div><!-- end col-md-3 -->

                <div class="col-md-9">

                    <div class="form-group">
                        <label>Street Name</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>House/ Block No</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>Unit</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <label>Postal Code</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                </div><!-- end col-md-9 -->

            </div><!-- end row -->

            <div class="row">

                <div class="col-md-3">

                    <div class="form-group">
                        <label>By Contact</label>
                    </div><!-- end form-group -->
                                        		
                </div><!-- end col-md-3 -->

                <div class="col-md-9">

                    <div class="form-group">
                        <label>Phone No</label>
                        <input type="text" class="form-control" placeholder=""> 
                    </div><!-- end form-group -->

                </div><!-- end col-md-9 -->

            </div><!-- end row -->

            <div class="row">

                <div class="col-md-12">

                    <div class="form-group">
                    </div><!-- end form-group -->

                    <div class="form-group">
                        <button type="submit" class="btn green" style="width: 100px; margin-right: 25px;">New
                        </button>
	                   <button type="button" class="btn default" style="margin-right: 25px;">Quick Search
	                   </button>
	                   <button type="submit" class="btn default">New Search</button>
                    </div><!-- end form-group -->
                                        		
                </div><!-- end col-md-12 -->

            </div><!-- end row -->
                                        
        </div><!-- end inbox-sidebar -->

    </div><!-- end col-md-3 -->