<div class="page-prefooter">
                    
                    <div class="container">
                        
                        <div class="row">
                            
                            <div class="col-md-3 col-sm-6 col-xs-12 footer-block">
                                <h2>About</h2>
                                <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam dolore. </p>
                            </div>
                            
                            <div class="col-md-3 col-sm-6 col-xs12 footer-block">
                                <h2>Subscribe Email</h2>
                                
                                <div class="subscribe-form">
                                    <form action="javascript:;">
                                        <div class="input-group">
                                            <input type="text" placeholder="mail@email.com" class="form-control">
                                            <span class="input-group-btn">
                                                <button class="btn" type="submit">Submit</button>
                                        	</span>
                                    	</div>
                                    </form>
                                </div><!-- end subscribe-form -->

                            </div><!-- end col-md-3 col-sm-6 col-xs12 footer-block -->

                            <div class="col-md-3 col-sm-6 col-xs-12 footer-block">
                                
                                <h2>Follow Us On</h2>
                                
                                <ul class="social-icons">
                                    
                                    <li>
                                            <a href="javascript:;" data-original-title="rss" class="rss"></a>
                                   	</li>

                                    <li>
                                        <a href="javascript:;" data-original-title="facebook" class="facebook"></a>
                                    </li>

                                    <li>
										<a href="javascript:;" data-original-title="twitter" class="twitter"></a>
                                    </li>

                                    <li>
                                        <a href="javascript:;" data-original-title="googleplus" class="googleplus"></a>
                                    </li>

                                    <li>
                                        <a href="javascript:;" data-original-title="linkedin" class="linkedin"></a>
                                    </li>

                                    <li>
                                        <a href="javascript:;" data-original-title="youtube" class="youtube"></a>
                                    </li>

                                    <li>
                                        <a href="javascript:;" data-original-title="vimeo" class="vimeo"></a>
                                    </li>

                                </ul>
                            </div><!-- end col-md-3 col-sm-6 col-xs-12 footer-block -->

                            <div class="col-md-3 col-sm-6 col-xs-12 footer-block">
                                <h2>Contacts</h2>
                                <address class="margin-bottom-40"> Phone: 800 123 3456
                                    <br> Email:
                                    <a href="mailto:info@metronic.com">info@metronic.com</a>
                                </address>
                        	</div><!-- end col-md-3 col-sm-6 col-xs-12 footer-block -->
                        
                        </div><!-- end row -->

                    </div><!-- end container -->
                </div><!-- end page-prefooter -->
                    
                <div class="page-footer">
                    <div class="container"> 2016 &copy; Metronic Theme By
                        <a target="_blank" href="http://keenthemes.com">Keenthemes</a> &nbsp;|&nbsp;
                        <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" title="Purchase Metronic just for 27$ and get lifetime updates for free" target="_blank">Purchase Metronic!</a>
                    </div>
                </div>

                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div><!-- end scroll-to-top -->